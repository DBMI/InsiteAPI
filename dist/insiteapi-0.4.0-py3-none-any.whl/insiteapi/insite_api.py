"""
Contains InSiteAPI class.
"""

from __future__ import annotations

import csv
import logging
import os
import threading
import time
from collections.abc import Callable
from pathlib import Path

import requests

from insiteapi.aou_package import AouPackage
from insiteapi.gcloud_tools import GCloudTools
from insiteapi.progress import Progress


def join_headers(h1: list, h2: list) -> list:
    """
    Joins two lists into one list.

    Parameters
    ----------
    h1: list
    h2: list

    Returns
    -------
    combined: list
    """
    if not h1:
        if not h2:
            return []
        return h2
    if not h2:
        return h1

    set1: set = set(h1)
    set2: set = set(h2)
    combined: set = set1 | set2
    return list(combined)


def make_header(dict1: dict) -> list:
    """
    Turns a dictionary keys into a header list.

    Parameters
    ----------
    dict1: dict

    Returns
    -------
    list
    """
    return list(dict1.keys())


class InSiteAPI(threading.Thread):
    """
    An interface with the AwardeeInSite API

    Parameters
    ----------
    self.__aou_package
    self.data
    self.__official_header
    self.__report_fn
    self.__stop_event
    self.__token

    Methods
    ---------
    output_data()
    run()
    """

    def __init__(
        self,
        aou_package: AouPackage,
        log: logging.Logger,
        report_fn: Callable[[str], None] | None = None,
    ):
        """Instantiate an InSiteAPI object.

        Parameters
        ----------
        aou_package: AouPackage     Contains variables needed to request participant data.
        log: logging.Logger
        report_fn: Callable         Optional Tell something to calling function
        """
        # Set up ability of calling function to stop data request.
        threading.Thread.__init__(self)
        self.__stop_event: threading.Event = threading.Event()

        # Everything we'll need to make request.
        self.__aou_package: AouPackage = aou_package

        # Property used to record results.
        self.__data: dict = {}

        # Logger
        self.__log: logging.Logger = log
        log.info("InSiteAPI initialized.")

        # Variables developed in request_list() to be used in output_data().
        self.__official_header: list = []

        # We can use these to report to calling function how & what we're doing.
        self.__report_fn: Callable = report_fn

        # Status
        self.__progress: Progress = Progress()

        # Instantiate the GCloud Tool object we'll need.
        self.__log.info("Instantiating the GCloudTools object.")
        self.__gcloud_mgr: GCloudTools = GCloudTools(
            aou_package=self.__aou_package,
            log=self.__log,
            status_fn=self.__auth_report,
        )

        # Insert dummy value in __token.
        self.__token = ''

        # Get the authorization we need.
        self.__log.info("Getting authorization via the GCloudTools object.")
        self.__gcloud_mgr.run()

    def __auth_report(self, progress: bool | int | str) -> None:
        """
        Allow external method to either change status bar, gauge or report completion.

        Parameters
        ----------
        progress: Union[bool, int, str]
        """
        if isinstance(progress, bool):
            self.__on_auth_completion()
        elif isinstance(progress, int):
            self.__log.info(f"Progress: {int(progress)}")
        elif isinstance(progress, str):
            self.__log.info(f"Progress: {str(progress)}")

    def __build_line(self, d: dict) -> list:
        """
        Handles putting together output package from dictionary.

        Parameters
        ----------
        d: dict         One organization's data

        Returns
        -------
        line: list      To be written out
        """

        line: list = []

        for h in self.__official_header:
            try:
                if d[h] != "UNSET":
                    line.append(d[h])
                else:
                    line.append("")
            except KeyError:  # pragma: no cover
                line.append("")  # pragma: no cover

        return line

    def __extract_organization_data(self, resource: dict) -> None:
        """
        Updates the self.__data dictionary given one entry.

        Parameters
        ----------
        resource: dict

        """

        if "organization" in resource:
            organization: str = resource["organization"]

            if organization is None or organization.strip() == "":
                resource["organization"] = "Unpaired"
                organization = resource["organization"]

            if organization not in self.__data:
                self.__data[organization] = []

            self.__data[organization].append(resource)

    def __handle_timeouts(
        self,
        resp: requests.Response,
        next_url: str | None,
        headers: dict,
    ) -> dict:
        """
            Handles the details of timeouts & other errors.

        Parameters
        ----------
        resp: requests.Response
        next_url: str               Exact ping address
        headers: dict               How we want data reported

        Returns
        -------
        ps_data: dict
        """
        num_reattempts: int = 0
        ps_data: dict = {}
        self.__log.debug("in __handle_timeouts")
        status_code: str
        resp_text: str

        while True:
            status_code = (
                str(resp.status_code)
                if isinstance(resp, requests.Response) and resp.status_code
                else "Unknown status"
            )
            resp_text = (
                resp.text
                if isinstance(resp, requests.Response) and resp.text
                else "Unknown error"
            )

            self.__log.debug(f"Status code: {status_code}: {resp_text}.")

            if num_reattempts < 2:
                self.__log.debug(
                    f"Have made {num_reattempts} reattempts. Pausing for another try."
                )
                time.sleep(30)

                try:
                    resp = requests.get(next_url, headers=headers, timeout=60)
                except requests.exceptions.RequestException:
                    self.__log.error("API request failed. Exiting.")

                    if self.__report_fn is not None:
                        self.__report_fn("API request failed. Exiting.")

                    raise RuntimeError("API request failed. Exiting.")

                num_reattempts += 1
            else:
                self.__log.error(f"Have made {num_reattempts} reattempts. Exiting.")

                if self.__report_fn is not None:
                    self.__report_fn(f"Have made {num_reattempts} reattempts. Exiting.")

                raise RuntimeError(f"Have made {num_reattempts} reattempts. Exiting.")

            if resp.status_code == 200:
                self.__log.debug(f"Success after {num_reattempts} reattempts.")
                ps_data = resp.json()
                break
            elif resp.status_code == 500:
                # Server error. Stay in loop; we'll pause & try again.
                self.__log.error(
                    "Server error: %s. Have made %d attempts.",
                    status_code,
                    num_reattempts,
                )
            else:
                # It's some other code--not likely to be fixed with another attempt.
                self.__log.error(f"Status code: {status_code}: {resp_text}.")

                if self.__report_fn is not None:
                    self.__report_fn(f"Status code: {status_code}: {resp_text}.")

                raise RuntimeError(f"Status code: {status_code}: {resp_text}.")

        return ps_data

    def __on_auth_completion(self) -> None:
        """
        Event handler for when GCloud thread completes.
        """
        self.__token = self.__gcloud_mgr.get_token()

    def output_data(self, data_directory: str) -> None:
        """
        Produces .csv files from extracted data.

        Parameters
        ----------
        data_directory: str                             Where do you want the files to be created?

        Returns
        -------
        None
        """

        self.__official_header.sort()

        # Ensure the path to the data directory exists.
        data_directory_path: Path = Path(data_directory)
        data_directory_path.mkdir(parents=True, exist_ok=True)

        for key, value in self.__data.items():
            csv_filepath = os.path.join(data_directory, key + "_participant_list.csv")

            if self.__report_fn is not None:
                self.__report_fn(f"Writing to {csv_filepath}")
            else:
                self.__log.info("Writing to %s", csv_filepath)

            with open(csv_filepath, "w", newline="", encoding="utf-8") as file:
                writer: csv.writer = csv.writer(file)
                writer.writerow(self.__official_header)

                for d in value:
                    line: list = self.__build_line(d)
                    writer.writerow(line)

    def __report_completion(self) -> None:
        """
        Handles call to external function.
        """
        # Let calling function know we're done.
        if self.__report_fn is not None:
            self.__report_fn(True)

    def __report_progress(
        self,
        num_new_records: int,
    ) -> None:
        """
        Takes care of logging & external status functions.

        Parameters
        ----------
        num_new_records: int
        """
        self.__progress.increment(num_new_records)
        comment: str = "Success: retrieved %d records. Total records: %d"
        self.__log.info(comment, num_new_records, self.__progress.num_complete())

        if self.__report_fn is not None:
            self.__log.debug("Calling external progress function.")
            self.__report_fn(self.__progress.percent_complete())

    def __request_response(self, next_url: str | None, headers: dict) -> dict:
        """
        Handles the http request, retries, etc.

        Parameters
        ----------
        next_url: URL of request
        headers: list

        Returns
        -------
        ps_data: dict of retrieved data
        """
        ps_data: dict = {}

        self.__log.debug(f"Requesting {next_url}")

        try:
            resp: requests.Response = requests.get(
                next_url, headers=headers, timeout=30
            )

            if resp.status_code == 200:
                self.__log.debug(f"status code: {resp.status_code}")
                ps_data = resp.json()
                self.__test_for_bundle(ps_data)
            else:
                self.__log.debug(
                    "Sending to timeout handler because received response but status code is not 200."
                )
                ps_data = self.__handle_timeouts(
                    resp=resp, next_url=next_url, headers=headers
                )

            if (
                isinstance(ps_data, dict)
                and "total" in ps_data
                and not self.__progress.is_set()
            ):
                self.__log.debug(f"Total records: {ps_data['total']}")
                self.__progress.set(ps_data["total"])
        except requests.exceptions.RequestException:
            # We didn't even get a valid response.
            self.__log.error("Error: API request failed. Exiting.")
            raise RuntimeError("Error: API request failed. Exiting.")

        return ps_data

    def run(self) -> None:
        """
        Request data from AwardeeInSite API; creates data: dict by organization
        """
        self.__log.info("Starting InSite API object running.")

        # Constants
        num_rows_per_page: int = 1000

        headers: dict = {
            "content-type": "application/json",
            "Authorization": f"Bearer {self.__token}",
        }

        aou_package: AouPackage = self.__aou_package
        next_url: str | None = (
            f"{aou_package.endpoint}?_sort=lastModified&_includeTotal=TRUE"
            f"&_count={num_rows_per_page}&awardee={aou_package.awardee}"
        )

        self.__log.debug("next_url: %s", next_url)

        self.__data = {}

        while next_url and not self.__stop_event.is_set():
            ps_data: dict = self.__request_response(next_url, headers)
            self.__report_progress(len(ps_data["entry"]))

            for entry in ps_data["entry"]:
                resource = entry["resource"]
                h = make_header(resource)
                self.__official_header = join_headers(self.__official_header, h)
                self.__extract_organization_data(resource)

            next_url = self.__update_url(ps_data)

        # Let calling function know we're done.
        self.__report_completion()

    def stop(self) -> None:
        """
        Lets calling function tell us to stop.
        """
        self.__log.info("Stop requested")
        self.__stop_event.set()

    def __test_for_bundle(self, ps_data: dict) -> None:
        """
            Tests to ensure dictionary is as expected.

        Parameters
        ----------
        ps_data: dict
        """

        if (
            "resourceType" not in ps_data
            or ps_data["resourceType"] != "Bundle"
            or "entry" not in ps_data
        ):
            self.__log.error("No bundle")
            raise RuntimeError("Unable to find required fields in dict 'ps_data'.")

    def __update_url(self, ps_data: dict) -> str:
        """
        Get url of next page from the returned data.

        Parameters
        ----------
        ps_data: dict

        Returns
        -------
        next_url: str
        """
        next_url: str | None = None

        try:
            next_url_info: dict = ps_data["link"][0]

            if next_url_info["relation"] == "next":
                next_url = next_url_info["url"]

            self.__log.debug("------------------")
            self.__log.debug(next_url)
        except KeyError:
            self.__log.error("Key error")

        return next_url
