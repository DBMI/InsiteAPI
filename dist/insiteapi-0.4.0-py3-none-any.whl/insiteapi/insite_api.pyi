import logging
import threading
from collections import namedtuple
from collections.abc import Callable as Callable
from insiteapi.aou_package import AouPackage
from insiteapi.gcloud_tools import GCloudTools
import requests
from progress import Progress

# Fold resp, num_attempts into a named tuple.
ResponsePackage = namedtuple("ResponsePackage", ["resp", "num_attempts"])

def join_headers(h1: list, h2: list) -> list: ...
def make_header(dict1: dict) -> list: ...

class InSiteAPI(threading.Thread):
    __aou_package: AouPackage = None
    __data: dict = None
    __gcloud_mgr: GCloudTools
    __log: logging.Logger = None
    __official_header: list = None
    __report_fn: Callable[str] | None = None
    __stop_event: threading.Event = None
    __progress: Progress = None
    __token: str = None

    def __init__(
        self,
        aou_package: AouPackage,
        log: logging.Logger,
        report_fn: Callable[str] | None,
    ) -> None: ...
    def __auth_report(self, progress: bool | int | str) -> None:
    def __build_line(self, d: dict) -> list: ...
    def __extract_organization_data(self, resource: dict) -> None: ...
    def __handle_timeouts(
        self,
        resp: requests.Response,
        next_url: str | None,
        headers: dict,
    ) -> dict: ...
    def __on_auth_completion(self) -> None: ...
    def output_data(self, data_directory: str) -> None: ...
    def __report_completion(self) -> None: ...
    def __report_progress(self, num_new_records: int) -> None: ...
    def __request_response(self, next_url: str | None, headers: dict) -> dict: ...
    def run(self) -> None: ...
    def stop(self) -> None: ...
    def __test_for_bundle(self, ps_data: dict) -> None: ...
    def __update_url(self, ps_data: dict) -> str: ...
